// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Hash with XXH3"); }
int main(){
  announce();
  return lionss_run_workload("xxhash3");
}
